		package com.practice.util;
		
		import java.sql.Connection;
		import java.sql.DriverManager;
		import java.sql.ResultSet;
		import java.sql.SQLException;
		import java.sql.Statement;
		
		public class JdbcUtil 
		{
			
			private JdbcUtil() {
			
			}
			
			
			public static Connection getJdbcConnection() throws SQLException
			{
				Connection con = null;
				
				String url = "jdbc:mysql:///enterprisejava";
				String user = "root";
				String pwd = "12345678";
				
				con = DriverManager.getConnection(url, user, pwd);
				
				if(con != null)
					return con;
				
				return con;
			}
			
			
			public static void closeJdbcConnection(ResultSet rs, Statement stmt, Connection conn) throws SQLException
			{
				if(rs != null)
					rs.close();
		
				if(stmt != null)
					stmt.close();
		
				if(conn != null)
					conn.close();
			}
			
			
		}
