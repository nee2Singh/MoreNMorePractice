package com.practice.jdbccrud;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class DeleteDbData 
{

	public static void main(String[] args) 
	{
		
		Connection conn = null;
		Statement stmt = null;
		
		Scanner scan = new Scanner(System.in);
		String sqlDelete = "";
		int rowsUpdated = 0;
		
		System.out.print("Please Enter Student Id to Delete the record :: ");
		int stuId = scan.nextInt();
		
		try {
			
			

			conn = JdbcUtil.getJdbcConnection();
			
			if(conn != null)
				stmt = conn.createStatement();
			
			if(stmt != null)
			{
				sqlDelete = "delete from student where id = "+stuId;
				
				System.out.println("sqlDelete === "+sqlDelete);
				
				rowsUpdated = stmt.executeUpdate(sqlDelete);
				
				if(rowsUpdated > 0)
					System.out.println("Record deleted successfully in the table.");
				else
					System.out.println("There is some error in deleting the record.");
			}

		}
		catch(SQLException se)	{
			
			System.out.println(se.getMessage());
		}
		catch(Exception e)	{
			
			System.out.println(e.getMessage());
		}
		finally	{
			
			try {
				JdbcUtil.closeJdbcConnection(null, stmt, conn);
				
				if(scan != null)
					scan.close();
			}
			catch(SQLException se) {
				
				System.out.println(se.getMessage());
			}
		}
	}

}
