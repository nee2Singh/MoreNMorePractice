package com.practice.jdbccrud;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class InsertDataInDB 
{
	public static void main(String[] args)
	{
		
		Connection conn = null;
		Statement stmt = null;
		Scanner scan = new Scanner(System.in);
		String sqlInsert = "";
		int rowsUpdated = 0;
		
		try {
			
			System.out.print("Please Enter Student Name :: ");
			String stuName = scan.next();

			System.out.print("Please Enter Student Address :: ");
			String stuAddr = scan.next();
			
			conn = JdbcUtil.getJdbcConnection();
			
			if(conn != null)
				stmt = conn.createStatement();
			
			if(stmt != null)
			{
				sqlInsert = "insert into student(`name`, `addr`)  values('"+stuName+"','"+stuAddr+"');";
				
				System.out.println("sqlInsert === "+sqlInsert);
				
				rowsUpdated = stmt.executeUpdate(sqlInsert);
				
				if(rowsUpdated > 0)
					System.out.println("Record inserted successfully in the table.");
				else
					System.out.println("There is some eeror in inserting the record.");
			}

		}
		catch(SQLException se)	{
			
			System.out.println(se.getMessage());
		}
		catch(Exception e)	{
			
			System.out.println(e.getMessage());
		}
		finally	{
			
			try {
				JdbcUtil.closeJdbcConnection(null, stmt, conn);
				
				if(scan != null)
					scan.close();
			}
			catch(SQLException se) {
				
				System.out.println(se.getMessage());
			}
		}
	}
}
