package com.practice.jdbccrud;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class UpdateDbData 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		
		Connection conn = null;
		Statement stmt = null;
		
		int rowsUpdated = 0;
		String sqlUpdate = "";
		
		System.out.print("Please enter the Id to update the record :: ");
		int stuId = scan.nextInt();
		
		System.out.print("Please Enter Student Name to update :: ");
		String stuName = scan.next();

		System.out.print("Please Enter Student Address to update :: ");
		String stuAddr = scan.next();
		
		try {
			
			conn = JdbcUtil.getJdbcConnection();
			
			if(conn != null)
				stmt = conn.createStatement();
			
			if(stmt != null ) {
				
				sqlUpdate = "update student set name = '"+stuName+"', addr = '"+stuAddr+"' where id = "+ stuId;
				
				System.out.println("The querty is ==== "+sqlUpdate);
				
				rowsUpdated = stmt.executeUpdate(sqlUpdate);
				
				if(rowsUpdated > 0)
					System.out.println("Record updated successfully in the table.");
				else
					System.out.println("There is some eeror in updating the record.");
			}
		}
		catch(SQLException se) {
			
			System.out.println(se.getMessage());
		}
		catch(Exception e) {
			
			System.out.println(e.getMessage());
		}
		finally {

			try {

				JdbcUtil.closeJdbcConnection(null, stmt, conn);

				if(scan != null)
					scan.close();
			}
			catch(SQLException se) {

				System.out.println(se.getMessage());
			}
		}

	}

}
