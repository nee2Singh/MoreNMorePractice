package com.practice.jdbccrud;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class FetchDbData 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		String sqlSelect = "";
		
		System.out.print("Please enter the Id to fetch the record :: ");
		int stuId = scan.nextInt();
		
		try {
			
			conn = JdbcUtil.getJdbcConnection();
			
			if(conn != null)
				stmt = conn.createStatement();
			
			if(stmt != null ) {
				
				sqlSelect = "select id, name, addr from student where id = "+ stuId;
				
				System.out.println("The querty is ==== "+sqlSelect);
				
				rs = stmt.executeQuery(sqlSelect);
				
				if(rs != null)
				{
					System.out.println("ID\t\tNAME\t\tADDRESS");
					if(rs.next())
					{
						System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t"+rs.getString(3));
					}
				}
				else
					System.out.println("There is not record available for id :: "+stuId);
			}
		}
		catch(SQLException se) {
			
			System.out.println(se.getMessage());
		}
		catch(Exception e) {
			
			System.out.println(e.getMessage());
		}
		finally {

			try {

				JdbcUtil.closeJdbcConnection(rs, stmt, conn);

				if(scan != null)
					scan.close();
			}
			catch(SQLException se) {

				System.out.println(se.getMessage());
			}
		}

	}

}
