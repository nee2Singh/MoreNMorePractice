package com.practice.preparestmt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class DeleteDbData 
{
	public static void main(String[] args) throws SQLException
	{
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		int rowDeleted = 0;
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the id to be deleted :: ");
		String sId = scan.next();
		
		String sqlDelete = "delete from student where id = ?";
		
		try {
			
			conn = JdbcUtil.getJdbcConnection();
			
			if(conn != null)
				pstmt = conn.prepareStatement(sqlDelete);
			
			if(pstmt != null)
			{
				pstmt.setString(1, sId);
				
				System.out.println(sqlDelete);
				
				pstmt.execute();
			}
			
			if(rowDeleted > 0)
				System.out.println("row dleted");
			else
				System.out.println("error");
		}
		catch(SQLException se) {
			
			System.out.println(se.getMessage());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			JdbcUtil.closeJdbcConnection(null, pstmt, conn);
			
			if(scan != null)
				scan.close();
		}
	}
}
