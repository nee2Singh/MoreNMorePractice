package com.practice.preparestmt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class InsertRow 
{
	public static void main(String[] args) throws SQLException
	{
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rowUpdated = 0;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Please enter the name to enter :: ");
		String name = scan.next();
		
		System.out.print("Please enter the address to enter :: ");
		String addr = scan.next();
		
		String sqlInsert = "Insert into student(`name`, `addr`) values (?, ?)";
		
		try {
			
			conn = JdbcUtil.getJdbcConnection();
			
			if(conn != null)
				pstmt = conn.prepareStatement(sqlInsert);
			
			if(pstmt != null)
			{
				pstmt.setString(1, name);
				pstmt.setString(2, addr);
				
				System.out.println("Insert query ====   "+sqlInsert);
				
				rowUpdated = pstmt.executeUpdate();
			}
			
			if(rowUpdated > 0)
				System.out.println("Row added successfull ");
			else
				System.out.println("There was an error in query.");
		}
		catch(SQLException se) {
			
			System.out.println(se.getMessage());
		}
		finally {
			
			JdbcUtil.closeJdbcConnection(null, pstmt, conn);
			
			if(scan != null)
				scan.close();
		}
		
	}
}
