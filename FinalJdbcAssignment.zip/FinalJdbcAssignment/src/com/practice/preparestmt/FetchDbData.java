package com.practice.preparestmt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class FetchDbData 
{

	public static void main(String[] args) throws SQLException 
	{
		// Resource used in jdbc
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the sid: ");
		int sid = scanner.nextInt();

		String sqlSelectQuery = "select id, name, addr from student where id = ?";

		try {
			connection = JdbcUtil.getJdbcConnection();
			
			if (connection != null)
				pstmt = connection.prepareStatement(sqlSelectQuery);
	
			if (pstmt != null) {
				pstmt.setInt(1, sid);
				resultSet = pstmt.executeQuery();
			}
			
			if (resultSet != null) {
				
				if (resultSet.next()) {
					System.out.println("ID\t\tNAME\t\tADDR");
					System.out.println(resultSet.getInt(1) + "\t\t" + resultSet.getString(2) + "\t\t" + resultSet.getString(3));
				} else {
					System.out.println("Record not available for the given id:: " + sid);
				}
				
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.closeJdbcConnection(resultSet, pstmt, connection);
			if (scanner != null)
				scanner.close();
		}
	}

}
