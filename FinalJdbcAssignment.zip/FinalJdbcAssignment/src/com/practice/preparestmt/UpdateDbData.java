package com.practice.preparestmt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.practice.util.JdbcUtil;

public class UpdateDbData 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		int rowsUpdated = 0;
		String sqlUpdate = "";
		
		System.out.print("Please enter the Id to update the record :: ");
		int stuId = scan.nextInt();
		
		System.out.print("Please Enter Student Name to update :: ");
		String stuName = scan.next();

		System.out.print("Please Enter Student Address to update :: ");
		String stuAddr = scan.next();
		
		sqlUpdate = "update student set name = ?, addr = ? where id = ?";
		
		try {
			
			conn = JdbcUtil.getJdbcConnection();
			
			if(conn != null)
				pstmt = conn.prepareStatement("");
			
			if(pstmt != null ) {
				
				pstmt.setString(1, stuName);
				pstmt.setString(2, stuAddr);
				pstmt.setInt(3, stuId);
				
				System.out.println("The querty is ==== "+sqlUpdate);
				
				rowsUpdated = pstmt.executeUpdate(sqlUpdate);
				
				if(rowsUpdated > 0)
					System.out.println("Record updated successfully in the table.");
				else
					System.out.println("There is some eeror in updating the record.");
			}
		}
		catch(SQLException se) {
			
			System.out.println(se.getMessage());
		}
		catch(Exception e) {
			
			System.out.println(e.getMessage());
		}
		finally {

			try {

				JdbcUtil.closeJdbcConnection(null, pstmt, conn);

				if(scan != null)
					scan.close();
			}
			catch(SQLException se) {

				System.out.println(se.getMessage());
			}
		}

	}

}
